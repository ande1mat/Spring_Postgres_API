package com.springjpa.service;

import com.springjpa.Dtomapper.ApiDTOBuilder;
import com.springjpa.dto.CustomerDto;
import com.springjpa.model.Customer;
import com.springjpa.repository.IUserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by z042183 on 10/14/18.
 * If the data needs any transformation, we do it in the service layer before send it to the DAO.
 * The DAO returns a entity or persistence object
 */
@Component
public class UserService implements IUserService {
    @Autowired
    private IUserDAO userDAO;

    @Override
    public CustomerDto getCustByUserId(Long id) {
        Customer cust = userDAO.getUser(id);

        //The service gets the entity resultset object and calls the Data Transfer Object Builder(DTOBuilder)
        // to convert the entity resultset into a Data Transfer Object (DTO).
        return ApiDTOBuilder.custToCustDTO(cust);
    }

    //Should be able to have other methods below that maps to different DTO responses based on end point


}
