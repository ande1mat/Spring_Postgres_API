package com.springjpa.service;

import com.springjpa.dto.CustomerDto;

/**
 * Created by z042183 on 10/14/18.
 */
public interface IUserService {
    public CustomerDto getCustByUserId(Long custid);
}