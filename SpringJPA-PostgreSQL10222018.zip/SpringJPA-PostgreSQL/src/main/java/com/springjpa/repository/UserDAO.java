package com.springjpa.repository;

import com.springjpa.model.Customer;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Created by z042183 on 10/14/18.
 *
 * https://medium.com/@josedrojasa/building-a-rest-api-using-spring-boot-2-0-69b5f6dd8da4
 * Java Persistence Annotation (JPA)
 *
 */
@Repository
public class UserDAO implements IUserDAO {
    @PersistenceContext
    EntityManager em;

    //Returns the User whose id is the parameter 'id'.
    @Override
    public Customer getUser(Long id) {
        // The find's method search a record using the primary key.
        return em.find(Customer.class, id);
    }

    //should be able to have other persistence methods below


}