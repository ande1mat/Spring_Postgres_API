package com.springjpa.repository;

import com.springjpa.model.Customer;

/**
 * Created by z042183 on 10/14/18.
 */
public interface IUserDAO {
    //Create an interface to the Customer Model, this interface gets implemented in the Repository DAO
    //Created to seperate logic from the implementation.  The implementation happens in the UserDAO, where we
    //call a Postgres Database, but that could be some other implemention to get the data from a file or other source
    //so the interface helps abstract that implementation of getUser.  You could have many different types of implementation
    //of this interface
    public Customer getUser(Long id);

}
