package com.springjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
Organization of this API - Maven Based for Dependencies
1. Controller calls Service object
2. Repository Interface to Models/DB Postgres
3. Models (your Table entities) – in this example no DTOs or using model mapper to separate your DB Entities from the user interaction with Controller.
4. Map Model object to DTO object you want to return to the controller
4.5 Created a Service, and the Controller calls the Service, Service calls the Repository object.
5. Added spring accuator and health end point
6. Maven Based dependancy Mgmt

************************************************************************************
** internal entities of a Spring application (Models)!!!
** external DTOs (Data Transfer Objects) that are published back to the client!!!
* **********************************************************************************

Simple example with string responses
http://javasampleapproach.com/spring-framework/use-spring-jpa-postgresql-spring-boot

MAPPING MODEL TO DTO MAIN EXAMPLE, and Returning a ResponseEntity JSON message
https://medium.com/@josedrojasa/building-a-rest-api-using-spring-boot-2-0-69b5f6dd8da4


TODOs Next:

4.5 Handle a structured JSON with a main section to insert into Customer, and add an array for Address and seperate table
5. add error handling in controller: http://www.springboottutorial.com/spring-boot-exception-handling-for-rest-services

6. dockerize this app and see it running with Docker Container.  that would make it deployable anywhere
7. See about putting this docker image in Minikube and adding secrets to it so they get pulled into Properties.
8. Add Unit Tests
9. Add logging via filebeat or logstash to ELK or somewhere else.
10. Add and create metrics pipeline and visualize the data

 */

@SpringBootApplication
public class SpringJpaPostgreSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaPostgreSqlApplication.class, args);
	}
}
