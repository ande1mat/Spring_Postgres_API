package com.springjpa.controller;

/**
 * Created by z042183 on 6/10/18.
 */

//import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.springjpa.dto.CustomerDto;
import com.springjpa.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class EventController {

    private UserService service;

    private static final Logger logger = LoggerFactory.getLogger(EventController.class);

    @Autowired
    public EventController(UserService service) {
        this.service = service;
    }


    /*
    @RequestMapping("/save")
    public String process(){
        // save a single Customer
        //repository.save(new Customer("Jack", "Smith"));


        // save a list of Customers
        repository.saveAll(Arrays.asList(new Customer("Adam", "Johnson"), new Customer("Kim", "Smith"),
                new Customer("David", "Williams"), new Customer("Peter", "Davis")));

        return "Done";
    }*/



    //@RequestMapping(value="/findbyCustid", method=RequestMethod.GET, produces="application/json" )
    @RequestMapping(value="/findbyCustid", method=RequestMethod.GET, produces="application/json")
    public ResponseEntity<CustomerDto> logIn(@RequestParam("id") Long id) {
        CustomerDto user = service.getCustByUserId(id);
        logger.info("get /findbyCustid called");
        return new ResponseEntity<>(user, HttpStatus.OK);
    }






}
