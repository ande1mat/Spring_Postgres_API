package com.springjpa.Dtomapper;

import com.springjpa.dto.CustomerDto;
import com.springjpa.model.Customer;

/**
 * Created by z042183 on 10/14/18.
 */
public class ApiDTOBuilder {
    public static CustomerDto custToCustDTO(Customer cust) {
        CustomerDto customerDto = new CustomerDto();
        customerDto.setFirstname(cust.getFirstName());
        customerDto.setLastname(cust.getLastName());
        return customerDto;
    }

    //Can have other mappings below based on what end point needs to return what

}
